(function () {
    document.addEventListener("DOMContentLoaded", function () {
        document.body.classList.remove("is-preload");

        var revealTargets = document.querySelectorAll(
            ".panel, .line-card, .gallery-card, .contact-panel, .item-card, .intro-card"
        );

        revealTargets.forEach(function (el) {
            el.classList.add("reveal");
        });

        if ("IntersectionObserver" in window) {
            var observer = new IntersectionObserver(
                function (entries) {
                    entries.forEach(function (entry) {
                        if (entry.isIntersecting) {
                            entry.target.classList.add("is-visible");
                            observer.unobserve(entry.target);
                        }
                    });
                },
                { threshold: 0.12 }
            );

            revealTargets.forEach(function (el) {
                observer.observe(el);
            });
        } else {
            revealTargets.forEach(function (el) {
                el.classList.add("is-visible");
            });
        }
    });
})();
